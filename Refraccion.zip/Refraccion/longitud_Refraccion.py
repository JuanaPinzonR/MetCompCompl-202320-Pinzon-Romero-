def procesar_archivo_yml(ruta_archivo):
    resultados = []

    with open(ruta_archivo, "r") as archivo_yml:
        contenido = archivo_yml.read()

        # Encontrar el índice donde inicia la tabla de datos
        inicio_tabla = contenido.find("data: |")
        fin_tabla = contenido.find("...", inicio_tabla)

        # Extraer la sección de datos y dividirla en líneas
        datos_tabla = contenido[inicio_tabla:fin_tabla].strip().split("\n")[1:]

        for linea in datos_tabla:
            # Dividir la línea en columnas utilizando el separador "|"
            columnas = linea.strip().split("|")

            # Extraer la longitud de onda (λ) y el índice de refracción (n)
            valores = [valor.strip() for valor in columnas if valor.strip()]
            if len(valores) >= 3:
                longitud_onda = float(valores[1])
                indice_refraccion = float(valores[2])
                resultados.append((longitud_onda, indice_refraccion))

    return resultados

# Ejemplo de uso
ruta_archivo_yml = "ruta/a/tu/archivo.yml"
resultado = procesar_archivo_yml(ruta_archivo_yml)
print(resultado)43