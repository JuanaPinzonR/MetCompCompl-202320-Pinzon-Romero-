import csv

# Abre el archivo CSV de entrada
with open('indices_refraccion.csv', 'r') as csv_file:
    csv_reader = csv.DictReader(csv_file)
    
    # Extrae los nombres de los materiales y almacénalos en una lista
    materiales = [row['Material'] for row in csv_reader]

# Crea el archivo de salida "materiales.txt" con los nombres de los materiales
with open('materiales.txt', 'w') as txt_file:
    for material in materiales:
        txt_file.write(material + '\n')

print("Archivo 'materiales.txt' creado exitosamente.")