# -*- coding: utf-8 -*-

import os
import glob
import csv
import matplotlib.pyplot as plt
import numpy as np
from Repaso_de_funciones import datos_material

def graficar_datos(longitud_onda, indice_refraccion, nombre_material):
    promedio_n = np.mean(indice_refraccion)
    desviacion_estandar_n = np.std(indice_refraccion)
    
    plt.figure(figsize=(10, 6))
    plt.plot(longitud_onda, indice_refraccion, label=nombre_material, linestyle='-', color='blue')
    plt.title(f'Índice de Refracción en función de Longitud de Onda para {nombre_material}')
    plt.xlabel('Longitud de Onda (λ)')
    plt.ylabel('Índice de Refracción (n)')
    plt.legend()
    plt.title(f'{nombre_material} (n̄={promedio_n:.2f}, σn={desviacion_estandar_n:.2f})')
    plt.grid(True)
    plt.show()

def procesar_materiales(archivo_materiales):
    with open(archivo_materiales, 'r') as file:
        lista_materiales = [line.strip() for line in file]
        #print(lista_materiales)
    for material in lista_materiales:
        resultados = datos_material(material)
        #print(resultados)
        if resultados:
            longitud_onda, indice_refraccion = zip(*resultados)
            graficar_datos(longitud_onda, indice_refraccion, material)
        else:
            print(f'No se pudo obtener información para {material}')

if __name__ == '__main__':
    archivo_materiales = 'materiales.txt'  # Nombre de tu archivo de materiales
    procesar_materiales(archivo_materiales)