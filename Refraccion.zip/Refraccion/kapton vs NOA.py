# -*- coding: utf-8 -*-
"""
1.5. Graficas de ındice de refraccion y longitud de onda.
Escriba una funci´on que generalice el ejercicio anterior y que ademas guarde la grafica creada en la carpeta
correspondiente a la categor´ıa del material. Utilizando esta funcion, construya las graficas de todos los
elementos en indices refraccion.csv
"""
import matplotlib.pyplot as plt
import numpy as np

from Repaso_de_funciones import *
# Función para obtener tuplas de índice de refracción
def graficar():
    # Código para leer y procesar el archivo YAML (como se mencionó anteriormente)
    carpetas_base = ["archivos_yml"]
    # Rutas de archivos YAML para Kapton y NOA138
    archivo_kapton =  obtener_ruta_archivo_yml("kapton", carpetas_base)
    archivo_noa138 = obtener_ruta_archivo_yml("noa1348", carpetas_base)
    
    # Obtener tuplas de índice de refracción para Kapton y NOA138
    tuplas_kapton = obtener_tuplas_indice_refraccion(archivo_kapton)
    tuplas_noa138 = obtener_tuplas_indice_refraccion(archivo_noa138)
    #print(tuplas_kapton, tuplas_noa138)
    # Separar λ y n para cada material
    lambda_kapton, n_kapton = zip(*tuplas_kapton[0:82])
    lambda_noa138, n_noa138 = zip(*tuplas_noa138)
    
    
    # Cálculo del promedio y la desviación estándar para Kapton
    promedio_kapton = np.mean(n_kapton)
    desviacion_kapton = np.std(n_kapton)
    
    # Cálculo del promedio y la desviación estándar para NOA138
    promedio_noa138 = np.mean(n_noa138)
    desviacion_noa138 = np.std(n_noa138)
    
    # Crear el gráfico
    plt.figure(figsize=(10, 6))
    
    # Graficar Kapton
    plt.plot(lambda_kapton, n_kapton, label='Kapton', linestyle='-', color='blue')
    
    # Graficar NOA138
    plt.plot(lambda_noa138, n_noa138, label='NOA138', linestyle='--', color='red')
    
    # Configurar títulos y etiquetas de los ejes
    plt.title(f'Índice de Refracción en función de Longitud de Onda')
    plt.xlabel('Longitud de Onda (λ)')
    plt.ylabel('Índice de Refracción (n)')

    # Mostrar leyenda
    plt.legend()

    # Mostrar promedio y desviación estándar en el título
    plt.title(f'Kapton (n̄={promedio_kapton:.2f}, σn={desviacion_kapton:.2f}) vs NOA138 (n̄={promedio_noa138:.2f}, σn={desviacion_noa138:.2f})')

    # Mostrar el gráfico
    plt.grid(True)
    plt.show()

graficar()