# -*- coding: utf-8 -*-
"""
Primer archivo. 


1.2. Descarga de archivos
Escriba un script desde la l´ınea de comandos de la terminal que lea este archivo, descargue los archivos .yml
asociados a cada material (el enlace en la cuarta columna) y los guarde por carpetas acordes a las categor´ıas.
Importante: Construya un archivo llamado indices refraccion terminal.txt donde escribe los comandos de la
terminal que utilizo en los dos puntos anteriores.



Este Script crea una carpeta con todos los archivos .yml organizados en carpetas

"""

import csv
import os
import requests

# Nombre del archivo de entrada
archivo_entrada = "indices_refraccion.csv"

# Crear una carpeta para los archivos descargados
carpeta_descargas = "archivos_yml"
if not os.path.exists(carpeta_descargas):
    os.mkdir(carpeta_descargas)

# Leer el archivo CSV y descargar los archivos .yml
with open(archivo_entrada, "r") as archivo_csv:
    lector_csv = csv.reader(archivo_csv)
    next(lector_csv)  # Saltar la primera fila (encabezados)
    for fila in lector_csv:
        nombre_material = fila[2]
        categoria = fila[1]

        enlace_yml = fila[3]  # Suponiendo que el enlace .yml está en la cuarta columna

        # Crear una carpeta para la categoría si no existe
        carpeta_categoria = os.path.join(carpeta_descargas, categoria)
        if not os.path.exists(carpeta_categoria):
            os.mkdir(carpeta_categoria)

        # Descargar el archivo .yml y guardarlo en la carpeta correspondiente
        respuesta = requests.get(enlace_yml)
        if respuesta.status_code == 200:
            ruta_archivo = os.path.join(carpeta_categoria, f"{nombre_material}.yml")
            with open(ruta_archivo, "wb") as archivo_yml:
                archivo_yml.write(respuesta.content)
            print(f"Archivo {nombre_material}.yml descargado y guardado en {ruta_archivo}")
        else:
            print(f"No se pudo descargar el archivo {nombre_material}.yml")

print("Descarga y organización de archivos .yml completada.")
