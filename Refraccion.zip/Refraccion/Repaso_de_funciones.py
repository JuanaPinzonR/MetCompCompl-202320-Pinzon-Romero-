# -*- coding: utf-8 -*-
"""
1.3. Repaso de funciones
Construya una funci´on en Python que reciba por par´ametro la ruta de un archivo .yml y procese el texto
para retornar un arreglo de tuplas (λi, ni) donde λi es la longitud de onda a la cual se obtiene el ´ındice de
refracci´on ni respectivo.


#Este script buscará el nombre del material en el archivo CSV y luego utilizará el nombre del 
fabricante correspondiente para buscar el archivo YAML en la estructura de carpetas archivos_yml. 

"""
import os
import glob
import csv

def obtener_fabricante_desde_csv(material, archivo_csv):
    with open(archivo_csv, 'r') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        for row in csv_reader:
            if row['Material'] == material:
                return row['Fabricante']
    return None

def obtener_ruta_archivo_yml(material, carpetas_base):
    for carpeta_base in carpetas_base:
        ruta_fabricantes = glob.glob(os.path.join(carpeta_base, '*'))
        
        for ruta_fabricante in ruta_fabricantes:
            ruta_archivo_yml = os.path.join(ruta_fabricante, f'{material}.yml')
            if os.path.exists(ruta_archivo_yml):
                print(f'Ruta del archivo YAML encontrado: {ruta_archivo_yml}')  # Agrega esta línea
                return ruta_archivo_yml

    return None





def obtener_tuplas_indice_refraccion(archivo):
    try:
        with open(archivo, 'r') as f:
            lines = f.readlines()

        tuplas = []
        en_datos = False

        for line in lines:
            line = line.strip()
            if line.startswith("DATA:"):
                en_datos = True
            elif en_datos and line.startswith("- type: tabulated n"):
                continue
            elif en_datos and line.startswith("  - type: tabulated k"):
                break
            elif en_datos and line:
                partes = line.split()
                if len(partes) == 2:
                    try:
                        lambda_i = float(partes[0])
                        ni = float(partes[1])
                        tuplas.append((lambda_i, ni))
                    except ValueError:
                        continue

        return tuplas

    except FileNotFoundError:
        print(f'El archivo {archivo} no se encontró.')
        return []  # Devolver una lista vacía en caso de error


    except FileNotFoundError:
        print(f'El archivo {archivo} no se encontró.')
        return []



def datos_material(nombre_material):
    archivo_csv = 'indices_refraccion.csv'  # Reemplaza con la ruta de tu archivo CSV
    carpetas_base = ['archivos_yml']  # Directorios base donde se buscarán los archivos YAML

    fabricante = obtener_fabricante_desde_csv(nombre_material, archivo_csv)
    
    #print(fabricante)
    
    if fabricante:
        ruta_archivo_yml = obtener_ruta_archivo_yml(nombre_material, carpetas_base)
        
        if ruta_archivo_yml:
            resultados = obtener_tuplas_indice_refraccion(ruta_archivo_yml)
            print(resultados)
            return resultados
        else:
            return None, None  # No se encontró el archivo YAML para el material
    else:
        return None, None  # No se encontró el fabricante para el material en el archivo CSV

# Ejemplo de uso:
nombre_material = "PEDOT"
#datos, ruta_yml = datos_material(nombre_material)

print(datos_material(nombre_material))
#print(datos_material(nombre_material))