import matplotlib as plt

def procesar_archivo_yml(ruta_archivo):
    resultados = []

    with open(ruta_archivo, "r") as archivo_yml:
        contenido = archivo_yml.read()

        # Encontrar el índice donde inicia la tabla de datos
        inicio_tabla = contenido.find("data: |")
        fin_tabla = contenido.find("...", inicio_tabla)

        # Extraer la sección de datos y dividirla en líneas
        datos_tabla = contenido[inicio_tabla:fin_tabla].strip().split("\n")[1:]

        for linea in datos_tabla:
            # Dividir la línea en columnas utilizando el separador "|"
            columnas = linea.strip().split("|")

            # Extraer la longitud de onda (λ) y el índice de refracción (n)
            valores = [valor.strip() for valor in columnas if valor.strip()]
            if len(valores) >= 3:
                longitud_onda = float(valores[1])
                indice_refraccion = float(valores[2])
                resultados.append((longitud_onda, indice_refraccion))

    return resultados

# Ejemplo de uso
"""  ruta_archivo_yml = "ruta/a/tu/archivo.yml"
    resultado = procesar_archivo_yml(ruta_archivo_yml)
    print(resultado)"""
    


# Datos de ejemplo para kapton y adhesivo óptico NOA138
ruta_kapton ="archivos_yml\French\PlÃ¡sticos Comerciales.yml"
ruta_noa138 ="archivos_yml\French\PlÃ¡sticos Comerciales.yml"

#print(procesar_archivo_yml(ruta_kapton))
kapton_datos = [(400, 1.5), (500, 1.6), (600, 1.7), (700, 1.8), (800, 1.9)]
noa138_datos = [(400, 1.55), (500, 1.56), (600, 1.58), (700, 1.59), (800, 1.61)]

# Calcular el n promedio y la desviación estándar para cada material
def calcular_estadisticas(datos):
    longitudes_ondas, indices_refraccion = zip(*datos)
    n_promedio = sum(indices_refraccion) / len(indices_refraccion)
    desviacion_estandar = (sum((n - n_promedio)**2 for n in indices_refraccion) / len(indices_refraccion))**0.5
    return n_promedio, desviacion_estandar

n_promedio_kapton, desviacion_estandar_kapton = calcular_estadisticas(kapton_datos)
n_promedio_noa138, desviacion_estandar_noa138 = calcular_estadisticas(noa138_datos)

# Crear la gráfica
plt.figure(figsize=(10, 6))
plt.errorbar(*zip(*kapton_datos), fmt='o-', label='Kapton')
plt.errorbar(*zip(*noa138_datos), fmt='o-', label='Adhesivo óptico NOA138')

# Configurar los títulos y etiquetas
plt.title(f'Índice de Refracción en función de la Longitud de Onda\nKapton: n_promedio={n_promedio_kapton:.2f} ± {desviacion_estandar_kapton:.2f}, NOA138: n_promedio={n_promedio_noa138:.2f} ± {desviacion_estandar_noa138:.2f}')
plt.xlabel('Longitud de Onda (nm)')
plt.ylabel('Índice de Refracción')
plt.legend()
plt.grid()
# Mostrar la gráfica
plt.show()