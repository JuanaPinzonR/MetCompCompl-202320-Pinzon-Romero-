# -*- coding: utf-8 -*-

import os              # Importar módulo para operaciones con el sistema de archivos
import glob            # Importar módulo para buscar archivos y directorios
import csv             # Importar módulo para leer archivos CSV
import matplotlib.pyplot as plt  
import numpy as np      
# Función para obtener el fabricante de un material desde un archivo CSV
def obtener_fabricante_desde_csv(material, archivo_csv):
    with open(archivo_csv, 'r') as csv_file:
        csv_reader = csv.DictReader(csv_file)  # Crear un lector de CSV basado en diccionarios
        for row in csv_reader:
            if row['Material'] == material:
                return row['Fabricante']  # Devuelve el fabricante si se encuentra en el archivo CSV
    return None  # Devuelve None si el material no se encuentra en el archivo CSV

# Función para obtener la ruta de un archivo YAML que corresponde a un material en carpetas específicas
def obtener_ruta_archivo_yml(material, carpetas_base):
    for carpeta_base in carpetas_base:
        ruta_fabricantes = glob.glob(os.path.join(carpeta_base, '*'))  # Busca todas las carpetas de fabricantes
        
        for ruta_fabricante in ruta_fabricantes:
            ruta_archivo_yml = os.path.join(ruta_fabricante, f'{material}.yml')  # Construye la ruta del archivo YAML
            if os.path.exists(ruta_archivo_yml):  # Comprueba si el archivo YAML existe
                print(f'Ruta del archivo YAML encontrado: {ruta_archivo_yml}')
                return ruta_archivo_yml  # Devuelve la ruta del archivo YAML si se encuentra

    return None  # Devuelve None si no se encuentra el archivo YAML

# Función para obtener tuplas de índice de refracción desde un archivo
def obtener_tuplas_indice_refraccion(archivo):
    try:
        with open(archivo, 'r') as f:
            lines = f.readlines()  # Leer todas las líneas del archivo

        tuplas = []  # Lista para almacenar tuplas (λi, ni)
        en_datos = False  # Indicador para saber si estamos dentro de la sección de datos

        for line in lines:
            line = line.strip()  # Elimina espacios en blanco al principio y al final de la línea
            if line.startswith("DATA:"):
                en_datos = True  # Comienza la sección de datos
            elif en_datos and line.startswith("- type: tabulated n"):
                continue  # Ignora líneas que indican tipo de datos (no necesarios)
            elif en_datos and line.startswith("  - type: tabulated k"):
                break  # Sal del bucle cuando termina la sección de datos
            elif en_datos and line:
                partes = line.split()  # Divide la línea en partes
                if len(partes) == 2:
                    try:
                        lambda_i = float(partes[0])  # Convierte la longitud de onda a float
                        ni = float(partes[1])       # Convierte el índice de refracción a float
                        tuplas.append((lambda_i, ni))  # Agrega la tupla (λi, ni) a la lista
                    except ValueError:
                        continue  # Ignora líneas que no se pueden convertir a números

        return tuplas  # Devuelve la lista de tuplas (λi, ni)

    except FileNotFoundError:
        print(f'El archivo {archivo} no se encontró.')
        return []  # Devuelve una lista vacía si el archivo no se encuentra

# Función para obtener datos de un material (nombre del fabricante, ruta del archivo YAML y tuplas de índice de refracción)
def datos_material(nombre_material):
    archivo_csv = 'indices_refraccion.csv'  # Nombre del archivo CSV con información de materiales
    carpetas_base = ['archivos_yml']       # Carpetas base donde se buscarán los archivos YAML

    fabricante = obtener_fabricante_desde_csv(nombre_material, archivo_csv)  # Obtiene el fabricante del material
    
    if fabricante:
        ruta_archivo_yml = obtener_ruta_archivo_yml(nombre_material, carpetas_base)  # Obtiene la ruta del archivo YAML
        
        if ruta_archivo_yml:
            resultados = obtener_tuplas_indice_refraccion(ruta_archivo_yml)  # Obtiene las tuplas de índice de refracción
            return resultados  # Devuelve las tuplas de índice de refracción si se encuentran
        else:
            return None, None  # Devuelve None si no se encuentra el archivo YAML
    else:
        return None, None  # Devuelve None si no se encuentra el fabricante en el archivo CSV

# Función principal para procesar materiales
def procesar_materiales():
    with open('materiales.txt', 'r') as archivo_materiales:  # Abre el archivo 'materiales.txt' en modo lectura
        for material in archivo_materiales:  # Itera sobre las líneas del archivo (cada línea contiene un nombre de material)
            nombre_material = material.strip()  # Elimina espacios en blanco al principio y al final del nombre del material
            resultados = datos_material(nombre_material)  # Obtiene los datos del material

            if resultados:  # Verifica si se obtuvieron resultados válidos
                longitud_onda, indice_refraccion = zip(*resultados)  # Separa las tuplas en dos listas

                # Crea una carpeta para la categoría si no existe
                categoria = obtener_fabricante_desde_csv(nombre_material, 'indices_refraccion.csv')
                carpeta_categoria = os.path.join('resultados', categoria)
                os.makedirs(carpeta_categoria, exist_ok=True)

                # Crea y guarda la gráfica en la carpeta correspondiente
                plt.figure(figsize=(8, 6))  # Crea una figura para el gráfico
                plt.plot(longitud_onda, indice_refraccion)  # Dibuja el gráfico de longitud de onda vs. índice de refracción
                plt.title(f'Índice de Refracción de {nombre_material}\nPromedio: {sum(indice_refraccion) / len(indice_refraccion):.2f}, Desviación Estándar: {np.std(indice_refraccion):.2f}')
                plt.xlabel('Longitud de Onda (λ)')  # Etiqueta del eje x
                plt.ylabel('Índice de Refracción (n)')  # Etiqueta del eje y
                plt.grid(True)  # Agrega una cuadrícula al gráfico
                ruta_guardado = os.path.join(carpeta_categoria, f'{nombre_material}_indice_refraccion.png')  # Ruta de guardado
                plt.savefig(ruta_guardado)  # Guarda el gráfico como una imagen
                plt.close()  # Cierra la figura para liberar memoria

                print(f'Gráfica de {nombre_material} guardada en {ruta_guardado}')  # Muestra un mensaje informativo



def graficar_datos(longitud_onda, indice_refraccion, nombre_material):
    promedio_n = np.mean(indice_refraccion)
    desviacion_estandar_n = np.std(indice_refraccion)
    
    plt.figure(figsize=(10, 6))
    plt.plot(longitud_onda, indice_refraccion, label=nombre_material, linestyle='-', color='blue')
    plt.title(f'Índice de Refracción en función de Longitud de Onda para {nombre_material}')
    plt.xlabel('Longitud de Onda (λ)')
    plt.ylabel('Índice de Refracción (n)')
    plt.legend()
    plt.title(f'{nombre_material} (n̄={promedio_n:.2f}, σn={desviacion_estandar_n:.2f})')
    plt.grid(True)
    plt.show()




