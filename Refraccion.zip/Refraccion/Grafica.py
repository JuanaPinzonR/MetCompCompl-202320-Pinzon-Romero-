import matplotlib.pyplot as plt

# Datos de ejemplo para kapton y adhesivo óptico NOA138
kapton_datos = [(400, 1.5), (500, 1.6), (600, 1.7), (700, 1.8), (800, 1.9)]
noa138_datos = [(400, 1.55), (500, 1.56), (600, 1.58), (700, 1.59), (800, 1.61)]

# Calcular el n promedio y la desviación estándar para cada material
def calcular_estadisticas(datos):
    longitudes_ondas, indices_refraccion = zip(*datos)
    n_promedio = sum(indices_refraccion) / len(indices_refraccion)
    desviacion_estandar = (sum((n - n_promedio)**2 for n in indices_refraccion) / len(indices_refraccion))**0.5
    return n_promedio, desviacion_estandar

n_promedio_kapton, desviacion_estandar_kapton = calcular_estadisticas(kapton_datos)
n_promedio_noa138, desviacion_estandar_noa138 = calcular_estadisticas(noa138_datos)

# Crear la gráfica
plt.figure(figsize=(10, 6))
plt.errorbar(*zip(*kapton_datos), fmt='o-', label='Kapton')
plt.errorbar(*zip(*noa138_datos), fmt='o-', label='Adhesivo óptico NOA138')

# Configurar los títulos y etiquetas
plt.title(f'Índice de Refracción en función de la Longitud de Onda\nKapton: n_promedio={n_promedio_kapton:.2f} ± {desviacion_estandar_kapton:.2f}, NOA138: n_promedio={n_promedio_noa138:.2f} ± {desviacion_estandar_noa138:.2f}')
plt.xlabel('Longitud de Onda (nm)')
plt.ylabel('Índice de Refracción')
plt.legend()
plt.grid()

# Mostrar la gráfica
plt.show()