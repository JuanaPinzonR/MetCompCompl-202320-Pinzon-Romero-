# -*- coding: utf-8 -*-
"""


1.4. ´Indice de refracci´on de un pl´astico y un adhesivo ´optico
Grafique el ´ındice de refracci´on en funci´on de la longitud de onda para el kapton (un pl´astico comercial) y
para el adhesiv´o ´optico NOA138. En el t´ıtulo incluya el nombre del material, su n promedio y la desviaci´on
est´andar de n. Incluya adem´as los respectivos t´ıtulos de los ejes y dem´as propiedades para que su gr´afico sea
claro.


La funcion busca en la carpetas  por los datos, solo va a funcionar si se ejecuraton
las funciones 1 y 2

Esta funcion calcula los elementos a graficar, los ordena y grafica. 

"""

import matplotlib.pyplot as plt
from Repaso_de_funciones import procesar_archivo_yml

"""
Ruta del Klapton:
    ./archivos_yml/French/PlÃ¡sticos Comerciales
    
Ruta al NOA138
    ./archivos_yml/French/Adhesivos Ã“pticos
"""

def Graficar_Materiales():
    # Datos para el Kapton (plástico comercial)
    kapton = procesar_archivo_yml("./archivos_yml/French/PlÃ¡sticos Comerciales.yml") 
    NOA138 = procesar_archivo_yml("./archivos_yml/Iezzi/Adhesivos Ã“pticos.yml")
    
    
    longitudes_de_onda_kapton = []
    indices_refraccion_kapton = []
    
    longitudes_de_onda_NOA138 = []
    indices_refraccion_NOA138 = []
    
    for tupla in kapton[0]:
    # Índices de refracción para Kapton
        longitudes_de_onda_kapton.append(tupla[0])
        indices_refraccion_kapton.append(tupla[1])
 
    
    for tupla in NOA138[0]:  
        # Datos para el adhesivo óptico NOA138
        longitudes_de_onda_NOA138.append(tupla[0])  # Longitudes de onda en nm
        indices_refraccion_NOA138.append(tupla[1])  # Índices de refracción para NOA138
    
    # Calcular el n promedio y la desviación estándar para Kapton
    n_promedio_kapton = sum(indices_refraccion_kapton) / len(indices_refraccion_kapton)
    desviacion_estandar_kapton = (sum((x - n_promedio_kapton) ** 2 for x in indices_refraccion_kapton) / len(indices_refraccion_kapton)) ** 0.5
    
    # Calcular el n promedio y la desviación estándar para NOA138
    n_promedio_NOA138 = sum(indices_refraccion_NOA138) / len(indices_refraccion_NOA138)
    desviacion_estandar_NOA138 = (sum((x - n_promedio_NOA138) ** 2 for x in indices_refraccion_NOA138) / len(indices_refraccion_NOA138)) ** 0.5
    
    # Crear las gráficas
    plt.figure(figsize=(10, 6))
    
    # Gráfica para Kapton
    plt.plot(longitudes_de_onda_kapton, indices_refraccion_kapton, label='Kapton')
    plt.xlabel('Longitud de Onda (nm)')
    plt.ylabel('Índice de Refracción')
    plt.title(f'Índice de Refracción vs. Longitud de Onda\nKapton (n_prom = {n_promedio_kapton:.2f}, σ = {desviacion_estandar_kapton:.2f})')
    plt.grid(True)
    
    # Gráfica para NOA138
    plt.plot(longitudes_de_onda_NOA138, indices_refraccion_NOA138, label='NOA138')
    plt.xlabel('Longitud de Onda (nm)')
    plt.ylabel('Índice de Refracción')
    plt.title(f'Índice de Refracción vs. Longitud de Onda\nNOA138 (n_prom = {n_promedio_NOA138:.2f}, σ = {desviacion_estandar_NOA138:.2f})')
    plt.grid(True)
    
    # Agregar leyendas y mostrar la gráfica
    plt.legend()
    plt.show()
    
Graficar_Materiales()