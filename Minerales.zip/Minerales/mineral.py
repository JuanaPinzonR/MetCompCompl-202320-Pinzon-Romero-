# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import numpy as np
class Mineral:

    def __init__(self, nombre, dureza, lustre, rompimiento_por_fractura, color, composicion, sistema_cristalino, specific_gravity):
        self.nombre = nombre
        self.dureza = dureza
        self.lustre = lustre
        self.rompimiento_por_fractura = rompimiento_por_fractura
        self.color = color
        self.composicion = composicion
        self.sistema_cristalino = sistema_cristalino
        self.specific_gravity = specific_gravity

    def es_silicato(self):
        """
        Verifica si el mineral es un silicato comprobando si tiene silicio (Si) y oxígeno (O) en su composición química.
        Devuelve True si es un silicato, False en caso contrario.
        """
        return 'Si' in self.composicion and 'O' in self.composicion

    def calcular_densidad_si(self):
        """
        Calcula la densidad del mineral en unidades SI (kg/m³).
        Utiliza la gravedad específica y la densidad del agua como referencia.
        """
        densidad_agua = 1000  # Densidad del agua en kg/m³
        densidad_mineral = self.specific_gravity * densidad_agua
        return densidad_mineral

    def visualizar_color_mas_comun(self):
        # Convierte el código hexadecimal del color a un formato RGB
        color_rgb = tuple(int(self.color[i:i+2], 16) for i in (1, 3, 5))

        color_image = np.zeros((1, 1, 3), dtype=np.uint8)
        color_image[0, 0, :] = color_rgb

        plt.imshow(color_image)
        plt.axis('off')
        plt.show()


    def imprimir_propiedades(self):
        """
        Imprime en la consola la dureza, el tipo de rompimiento y el sistema de organización de los átomos del mineral.
        """
        print(f'Dureza: {self.dureza}')
        print(f'Tipo de Rompimiento: {"Fractura" if self.rompimiento_por_fractura else "Escisión"}')
        print(f'Sistema de Organización de Átomos: {self.sistema_cristalino}')

# Ejemplo de uso
if __name__ == "__main__":
    mineral = Mineral(
        nombre="Cuarzo",
        dureza=7,
        lustre="Vítreo",
        rompimiento_por_fractura=True,
        color="#FAAAFF",
        composicion="SiO2",
        sistema_cristalino="Trigonal",
        specific_gravity=2.65
    )

    print(mineral.es_silicato())  
    print(mineral.calcular_densidad_si())  
    mineral.visualizar_color_mas_comun()  
    mineral.imprimir_propiedades()  
