# -*- coding: utf-8 -*-

# Importar la clase Mineral desde mineral.py
from mineral import Mineral

# Función para leer el archivo y crear los objetos Mineral
def crear_lista_minerales(archivo):
    lista_minerales = []

    with open(archivo, 'r', encoding='utf-8') as archivo_minerales:
        # Ignora la primera línea que contiene los encabezados
        next(archivo_minerales)

        for linea in archivo_minerales:
            campos = linea.strip().split('\t')
            nombre = campos[0]
            dureza = float(campos[1])
            rompimiento_por_fractura = campos[2] == 'TRUE'
            color = campos[3]
            composicion = campos[4]
            lustre = campos[5]
            specific_gravity = float(campos[6])
            sistema_cristalino = campos[7]

            mineral = Mineral(
                nombre=nombre,
                dureza=dureza,
                rompimiento_por_fractura=rompimiento_por_fractura,
                color=color,
                composicion=composicion,
                lustre=lustre,
                specific_gravity=specific_gravity,
                sistema_cristalino=sistema_cristalino
            )

            lista_minerales.append(mineral)

    return lista_minerales

# Función para contar minerales silicatos
def contar_silicatos(lista_minerales):
    contador_silicatos = 0

    for mineral in lista_minerales:
        if 'Si' in mineral.composicion and 'O' in mineral.composicion:
            contador_silicatos += 1

    return contador_silicatos

# Función para calcular la densidad promedio en formato SI
def calcular_densidad_promedio(lista_minerales):
    suma_densidades = sum(mineral.specific_gravity for mineral in lista_minerales)
    densidad_promedio = suma_densidades / len(lista_minerales)
    return densidad_promedio

if __name__ == '__main__':
    # Nombre del archivo de la tabla de minerales
    archivo_minerales = 'minerales.txt'


    lista_minerales = crear_lista_minerales(archivo_minerales)

    # Contar minerales silicatos
    cantidad_silicatos = contar_silicatos(lista_minerales)
    print(f'Número de minerales silicatos: {cantidad_silicatos}')

    # Calcular la densidad promedio
    densidad_promedio = calcular_densidad_promedio(lista_minerales)
    print(f'Densidad promedio en unidades SI: {densidad_promedio:.2f} g/cm³')


