# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
from ExpansionTermicaMineral import *

# Archivos CSV de datos para olivina y grafito
archivo_olivina = 'olivine_angel_2017.csv'
archivo_grafito = 'graphite_mceligot_2016.csv'

# Crear objetos ExpansionTermicaMineral para olivina y grafito
olivina_expansion = ExpansionTermicaMineral(
    nombre='Olivina',
    dureza=6.5,
    lustre='NO METÁLICO',
    rompimiento_por_fractura=True,
    color='#9ab973',
    composicion='(FeMg)2SiO4',
    sistema_cristalino='ORTORRÓMBICO',
    specific_gravity=3.9,
    archivo_csv = archivo_olivina
)

grafito_expansion = ExpansionTermicaMineral(
    nombre='Grafito',
    dureza=1.5,
    lustre='METÁLICO',
    rompimiento_por_fractura=False,
    color='#5f6168',
    composicion='C',
    sistema_cristalino='HEXAGONAL',
    specific_gravity=2.2,
    archivo_csv = archivo_grafito
)


# Cargar datos CSV para olivina y grafito
olivina_expansion.cargar_datos_csv(archivo_olivina)
grafito_expansion.cargar_datos_csv(archivo_grafito)

# Calcular coeficiente de expansión térmica para olivina y grafito
alpha_olivina, error_olivina = olivina_expansion.calcular_coeficiente_expansion_termica()
alpha_grafito, error_grafito = grafito_expansion.calcular_coeficiente_expansion_termica()

# Graficar el volumen V(T) y el coeficiente α(T) para olivina

plt.savefig('olivina_expansion.png')
plt.close()

# Graficar el volumen V(T) y el coeficiente α(T) para grafito

plt.savefig('grafito_expansion.png')
plt.close()

print(f'Coeficiente de expansión térmica para Olivina: {alpha_olivina:.6f}, Error: {error_olivina:.6f}')
print(f'Coeficiente de expansión térmica para Grafito: {alpha_grafito:.6f}, Error: {error_grafito:.6f}')
