# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import numpy as np
from mineral import Mineral

class ExpansionTermicaMineral(Mineral):
    def __init__(self, nombre, dureza, lustre, rompimiento_por_fractura, color, composicion, sistema_cristalino, specific_gravity, archivo_csv):
        super().__init__(nombre, dureza, lustre, rompimiento_por_fractura, color, composicion, sistema_cristalino, specific_gravity)
        self.temperaturas = []
        self.volumenes = []
        self.cargar_datos_csv(archivo_csv)

    def cargar_datos_csv(self, archivo_csv):
        with open(archivo_csv, 'r') as csv_file:
            next(csv_file)  # Saltar la primera línea que contiene los encabezados
            for line in csv_file:
                temperatura, volumen = map(float, line.strip().split(','))
                self.temperaturas.append(temperatura)
                self.volumenes.append(volumen)

    def calcular_coeficiente_expansion_termica(self):
        delta_volumen = np.diff(self.volumenes).astype(float)  # Convertir a flotantes
        delta_temperatura = np.diff(self.temperaturas).astype(float)  # Convertir a flotantes
        alphas = [1 / V * dVdT for V, dVdT in zip(self.volumenes[:-1], delta_volumen / delta_temperatura)]

        error_global = np.abs(np.mean(alphas) - alphas).astype(float) / np.mean(alphas).astype(float)

        plt.figure(figsize=(12, 6))

        plt.subplot(1, 2, 1)
        plt.plot(self.temperaturas, self.volumenes, marker='o', linestyle='-', color='b')
        plt.title('Volumen vs. Temperatura')
        plt.xlabel('Temperatura (°C)')
        plt.ylabel('Volumen (cm³)')

        plt.subplot(1, 2, 2)
        plt.plot(self.temperaturas[:-1], alphas, marker='o', linestyle='-', color='r')
        plt.title('Coeficiente de Expansión Térmica vs. Temperatura')
        plt.xlabel('Temperatura (°C)')
        plt.ylabel('Coeficiente de Expansión Térmica (α)')

        plt.tight_layout()
        plt.show()

        return alphas, error_global

# Ejemplo de uso
olivina_expansion = ExpansionTermicaMineral(nombre='Olivina', dureza=6.5, lustre='NO METÁLICO', rompimiento_por_fractura=True, color='#9ab973', composicion='(FeMg)2SiO4', sistema_cristalino='ORTORRÓMBICO', specific_gravity=3.9, archivo_csv='olivine_angel_2017.csv')
alphas, error_global = olivina_expansion.calcular_coeficiente_expansion_termica()
print(f'Coeficiente de Expansión Térmica: {alphas}')
print(f'Error Global: {error_global}')


# Ejemplo de uso:


